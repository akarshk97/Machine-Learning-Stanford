 Carr = [0.01;0.03;0.1;0.3;1;3;10;30];
sigmaarr = [0.01;0.03;0.1;0.3;1;3;10;30];
% a=rand(8)
% minMatrix = min(a(:));
% [row,col] = find(a==minMatrix);
% C = Carr(row(1))
% sigma = sigmaarr(col(1))

% for i=1:numel(Carr)
%     for j=1:numel(sigmaarr)
%         disp(Carr(i))
%         disp(sigmaarr(j))
%     end
% end

r=1;
r(1)